(()=>{
  const SUPABASE_URL='https://bqexugslkuvpymvdwoew.supabase.co';
  const SUPABASE_KEY='sb_publishable_hp6ySNVfwZV19x0ulSheLg_-hkx4Dbt';
  const PUBLIC_CODE='PUBLIC';
  const PLAYER_STALE_MS=30000;
  const HEARTBEAT_MS=8000;
  let sb=null,currentServer=PUBLIC_CODE,channel=null,heartbeat=null,serversChannel=null,playersChannel=null;
  let overlay,listEl,statusEl,createBtn,chip,toastEl;

  const uid=()=>{
    let id=localStorage.getItem('holeshot-player-id-v1');
    if(!id){id=(crypto.randomUUID?crypto.randomUUID():'hs-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));localStorage.setItem('holeshot-player-id-v1',id)}
    return id;
  };
  const displayName=()=>{
    let n=localStorage.getItem('holeshot-player-name-v1');
    if(!n){n='Rider '+uid().replace(/-/g,'').slice(-4).toUpperCase();localStorage.setItem('holeshot-player-name-v1',n)}
    return n;
  };
  const toast=(msg)=>{if(!toastEl)return;toastEl.textContent=msg;toastEl.classList.add('show');clearTimeout(toastEl._t);toastEl._t=setTimeout(()=>toastEl.classList.remove('show'),2200)};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const code=()=>Math.random().toString(36).slice(2,7).toUpperCase()+Math.random().toString(36).slice(2,5).toUpperCase();
  const ready=()=>window.supabase?.createClient && document.querySelector('#menu');

  function buildUI(){
    if(document.querySelector('#hs-server-overlay'))return;
    overlay=document.createElement('div');overlay.id='hs-server-overlay';overlay.innerHTML=`<div class="hs-server-shell"><div class="hs-server-head"><div><small>HOLESHOT ONLINE // GLOBAL NETWORK</small><h2>SERVERS</h2></div><button class="hs-server-close" aria-label="Close">×</button></div><div class="hs-server-list"><div class="hs-server-status"><span>CONNECTED AS <strong>${esc(displayName())}</strong></span><span id="hs-server-total">SYNCING...</span></div><div id="hs-server-items"><div class="hs-server-empty">CONNECTING TO HOLESHOT NETWORK...</div></div></div><div class="hs-server-foot"><p>PUBLIC LOBBY IS GLOBAL // CUSTOM SERVERS HAVE NO GAME-SIDE PLAYER CAP</p><button class="hs-server-create">CREATE YOUR SERVER +</button></div></div>`;
    document.body.appendChild(overlay);
    listEl=overlay.querySelector('#hs-server-items');statusEl=overlay.querySelector('#hs-server-total');createBtn=overlay.querySelector('.hs-server-create');
    overlay.querySelector('.hs-server-close').onclick=()=>overlay.classList.remove('open');overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.classList.remove('open')});
    createBtn.onclick=createServer;
    chip=document.createElement('div');chip.id='hs-lobby-chip';chip.innerHTML='<i></i><span>PUBLIC LOBBY</span>';document.body.appendChild(chip);
    toastEl=document.createElement('div');toastEl.className='hs-server-toast';document.body.appendChild(toastEl);
  }

  window.openHoleShotServers=()=>{
    buildUI();
    if(overlay){overlay.classList.add('open');refreshServers();}
  };

  function addMenuButton(){
    const menu=document.querySelector('#menu');if(!menu||document.querySelector('#hs-servers-button'))return false;
    const btn=document.createElement('button');btn.id='hs-servers-button';btn.innerHTML='<span>SERVERS</span><b>GLOBAL ↗</b>';btn.onclick=()=>window.openHoleShotServers();
    const links=menu.querySelector('.menu-links');
    const builder=menu.querySelector('#builder-button');
    if(links)links.appendChild(btn);else if(builder)builder.insertAdjacentElement('afterend',btn);else (menu.querySelector('.panel')||menu).appendChild(btn);
    return true;
  }

  async function setPresence(){
    if(!sb)return;
    const row={player_id:uid(),display_name:displayName(),server_code:currentServer,last_seen:new Date().toISOString()};
    try{await sb.from('holeshot_players').upsert(row,{onConflict:'player_id'})}catch(e){console.warn('presence',e)}
  }

  async function joinServer(serverCode,serverName){
    currentServer=serverCode||PUBLIC_CODE;
    localStorage.setItem('holeshot-current-server-v1',currentServer);
    if(channel){try{await sb.removeChannel(channel)}catch{}}
    channel=sb.channel('holeshot-game-'+currentServer,{config:{presence:{key:uid()},broadcast:{self:false}}});
    channel.on('presence',{event:'sync'},()=>refreshServers());
    channel.on('broadcast',{event:'player-ping'},()=>{});
    await channel.subscribe(async status=>{if(status==='SUBSCRIBED'){try{await channel.track({player_id:uid(),name:displayName(),joined_at:Date.now()})}catch{}}});
    await setPresence();
    // Keep the server browser and HoleShot's actual 3D rider-sync room in lockstep.
    try{if(window.__hsBuiltinNet){if(!window.__hsBuiltinNet.account)window.__hsBuiltinNet.guest(displayName());await window.__hsBuiltinNet.join(currentServer)}}catch(e){console.warn('3D rider room switch',e)}
    if(chip)chip.querySelector('span').textContent=(serverName||currentServer)+(currentServer===PUBLIC_CODE?'':' // SERVER');
    toast('JOINED '+(serverName||currentServer));
    refreshServers();
  }

  async function createServer(){
    if(!sb)return;
    const {data:owned}=await sb.from('holeshot_servers').select('*').eq('owner_key',uid()).eq('is_public',false).maybeSingle();
    if(owned){toast('YOU ALREADY OWN ONE SERVER');await joinServer(owned.server_code,owned.name);return}
    let name=prompt('Name your HoleShot server:',displayName()+"'s Server");
    if(name===null)return;name=name.trim().slice(0,28);if(!name)name=displayName()+"'s Server";
    const serverCode=code();
    const {error}=await sb.from('holeshot_servers').insert({owner_key:uid(),name,server_code:serverCode,is_public:false,last_seen:new Date().toISOString()});
    if(error){console.warn(error);toast('COULD NOT CREATE SERVER');return}
    toast('SERVER CREATED');await joinServer(serverCode,name);refreshServers();
  }

  async function deleteOwnServer(serverCode){
    if(!confirm('Delete your server?'))return;
    const {error}=await sb.from('holeshot_servers').delete().eq('server_code',serverCode).eq('owner_key',uid()).eq('is_public',false);
    if(error){toast('COULD NOT DELETE SERVER');return}
    if(currentServer===serverCode)await joinServer(PUBLIC_CODE,'PUBLIC LOBBY');
    toast('SERVER DELETED');refreshServers();
  }

  async function refreshServers(){
    if(!sb||!listEl)return;
    const cutoff=new Date(Date.now()-PLAYER_STALE_MS).toISOString();
    const [{data:servers,error:se},{data:players,error:pe}]=await Promise.all([
      sb.from('holeshot_servers').select('*').order('is_public',{ascending:false}).order('created_at',{ascending:true}),
      sb.from('holeshot_players').select('player_id,server_code,last_seen').gte('last_seen',cutoff)
    ]);
    if(se||pe){listEl.innerHTML='<div class="hs-server-empty">NETWORK CONNECTION ERROR — RETRYING...</div>';return}
    const counts={};(players||[]).forEach(p=>counts[p.server_code]=(counts[p.server_code]||0)+1);
    const rows=(servers||[]).sort((a,b)=>Number(b.is_public)-Number(a.is_public)||new Date(a.created_at)-new Date(b.created_at));
    statusEl.textContent=`${(players||[]).length} PLAYER${(players||[]).length===1?'':'S'} ONLINE`;
    const owned=rows.find(s=>s.owner_key===uid()&&!s.is_public);createBtn.disabled=!!owned;createBtn.textContent=owned?'YOUR SERVER ALREADY EXISTS':'CREATE YOUR SERVER +';
    listEl.innerHTML=rows.map(s=>{
      const isCurrent=s.server_code===currentServer, isMine=s.owner_key===uid()&&!s.is_public;
      return `<div class="hs-server-card ${s.is_public?'public':''} ${isCurrent?'current':''}"><div><div class="hs-server-title"><i></i>${esc(s.name)} ${s.is_public?'<span style="color:#d5ff65;font-size:9px;letter-spacing:1px">GLOBAL</span>':''}</div><div class="hs-server-meta"><span><b>${counts[s.server_code]||0}</b> PLAYERS</span><span>CODE <b>${esc(s.server_code)}</b></span><span>LIMIT <b>∞</b></span>${isMine?'<span><b>YOUR SERVER</b></span>':''}</div></div><div class="hs-server-actions"><button data-join="${esc(s.server_code)}" data-name="${esc(s.name)}" ${isCurrent?'disabled':''}>${isCurrent?'CONNECTED':'JOIN'}</button>${isMine?`<button class="danger" data-delete="${esc(s.server_code)}">DELETE</button>`:''}</div></div>`;
    }).join('')||'<div class="hs-server-empty">NO SERVERS FOUND</div>';
    listEl.querySelectorAll('[data-join]').forEach(b=>b.onclick=()=>joinServer(b.dataset.join,b.dataset.name));
    listEl.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteOwnServer(b.dataset.delete));
  }

  async function init(){
    buildUI();
    sb=window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
    // Requirement: every player enters the single global public lobby by default on every fresh game load.
    currentServer=PUBLIC_CODE;localStorage.setItem('holeshot-current-server-v1',PUBLIC_CODE);
    await joinServer(PUBLIC_CODE,'PUBLIC LOBBY');
    heartbeat=setInterval(setPresence,HEARTBEAT_MS);
    setInterval(refreshServers,10000);
    serversChannel=sb.channel('holeshot-server-list').on('postgres_changes',{event:'*',schema:'public',table:'holeshot_servers'},refreshServers).subscribe();
    playersChannel=sb.channel('holeshot-player-list').on('postgres_changes',{event:'*',schema:'public',table:'holeshot_players'},refreshServers).subscribe();
    refreshServers();
    window.addEventListener('beforeunload',()=>{try{navigator.sendBeacon(`${SUPABASE_URL}/rest/v1/holeshot_players?player_id=eq.${encodeURIComponent(uid())}`,new Blob([], {type:'application/json'}))}catch{}});
  }

  const timer=setInterval(()=>{
    if(ready()){
      buildUI();addMenuButton();clearInterval(timer);init().catch(e=>console.error('HoleShot multiplayer init',e));
    }
  },100);
  const menuTimer=setInterval(()=>{if(addMenuButton())clearInterval(menuTimer)},250);
})();
