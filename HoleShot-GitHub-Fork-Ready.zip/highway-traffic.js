(()=>{
  const btn=document.createElement('button');
  btn.id='highway-traffic-toggle';
  btn.type='button';
  const sync=()=>{
    const on=!!window.HoleShotHighwayTrafficEnabled;
    btn.innerHTML=`HIGHWAY TRAFFIC <strong>${on?'ON':'OFF'}</strong>`;
    btn.classList.toggle('on',on);
  };
  btn.addEventListener('click',()=>{
    window.HoleShotHighwayTrafficEnabled=!window.HoleShotHighwayTrafficEnabled;
    sync();
  });
  document.body.appendChild(btn);sync();
  setInterval(()=>{
    const st=window.__HOLESHOT_STATE__;
    const onHighway=!!st&&typeof st.x==='number'&&st.x<-900;
    btn.style.display=onHighway?'block':'none';
  },200);
})();
