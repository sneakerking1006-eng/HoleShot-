(()=>{
  const TIKTOK='https://www.tiktok.com/@holeshot.io?_r=1&_t=ZP-9ACwIYquhe3';
  const MUSIC_SRC='./the-kill.mp3';
  const LOGO_STING_SRC='./holeshot-logo-sting.mp3';
  const LOAD_MS=13800;
  const FADE_IN_MS=1700;
  const FADE_OUT_MS=1400;
  let musicStarted=false;
  const ready=()=>document.querySelector('#game') && document.querySelector('#menu') && document.querySelector('#play');

  function getMusic(){
    let a=document.querySelector('#hs-menu-audio');
    if(a) return a;
    a=document.createElement('audio');
    a.id='hs-menu-audio';
    a.src=MUSIC_SRC;
    a.preload='auto';
    a.autoplay=true;
    a.loop=false;
    a.volume=0;
    a.setAttribute('playsinline','');
    a.setAttribute('autoplay','');
    document.body.appendChild(a);
    return a;
  }

  function rampVolume(audio,from,to,duration,done){
    const start=performance.now();
    audio.volume=Math.max(0,Math.min(1,from));
    function tick(now){
      const t=Math.min(1,(now-start)/duration);
      const eased=t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
      audio.volume=Math.max(0,Math.min(1,from+(to-from)*eased));
      if(t<1) requestAnimationFrame(tick); else if(done) done();
    }
    requestAnimationFrame(tick);
  }

  async function startMusic(){
    const a=getMusic();
    if(musicStarted && !a.paused) return true;
    try{
      a.currentTime=0;
      a.volume=0;
      await a.play();
      musicStarted=true;
      rampVolume(a,0,.78,FADE_IN_MS);
      return true;
    }catch(e){
      musicStarted=false;
      console.warn('HoleShot intro music autoplay was blocked until a user gesture.',e);
      return false;
    }
  }

  function stopMusicWithFade(done){
    const a=getMusic();
    if(a.paused){a.currentTime=0; musicStarted=false; if(done)done(); return;}
    const from=a.volume;
    rampVolume(a,from,0,FADE_OUT_MS,()=>{
      a.pause();
      a.currentTime=0;
      musicStarted=false;
      if(done)done();
    });
  }


  function makePowerGate(onStart){
    if(document.querySelector('#hs-power-gate')) return;
    const gate=document.createElement('div');
    gate.id='hs-power-gate';
    gate.innerHTML=`<div class="hs-power-bg"></div><div class="hs-power-grid"></div><div class="hs-power-noise"></div><div class="hs-power-beam"></div><div class="hs-power-road"></div><div class="hs-power-bloom"></div><div class="hs-power-crosshair"><i></i><i></i></div><div class="hs-power-topline"><span>HOLESHOT INTERACTIVE</span><b>RIDGE COUNTY // LIVE BUILD</b></div><div class="hs-power-sidecode">HS // 77<br>RIDE SYSTEM<br>ONLINE</div><div class="hs-power-wrap"><div class="hs-power-kicker"><i></i> PRIVATE TEST BUILD // RIDGE COUNTY</div><div class="hs-power-title">HOLE<span>SHOT</span></div><div class="hs-power-copy">NO TRACK LIMITS. NO PERFECT LINE. JUST RIDE.</div><div class="hs-power-chips"><span>STREET</span><span>DIRT</span><span>RIDEOUTS</span><span>STUNTS</span></div><button id="hs-power-button"><b>ENTER HOLESHOT</b><span>↗</span></button><div class="hs-power-tip">AUDIO UNLOCKS ON ENTRY // HEADPHONES RECOMMENDED</div></div><div class="hs-power-meter"><i></i><i></i><i></i><i></i><i></i><span>POWER BUS // ARMED</span></div><div class="hs-power-corners"><i></i><i></i><i></i><i></i></div>`;
    document.body.appendChild(gate);
    const btn=gate.querySelector('#hs-power-button');
    let fired=false;
    btn.addEventListener('click',()=>{
      if(fired)return; fired=true; btn.disabled=true;
      gate.classList.add('hs-power-fired');
      // Launch the real intro immediately from this trusted click so browsers allow its sound.
      if(onStart)onStart();
      setTimeout(()=>{gate.classList.add('hs-power-out');setTimeout(()=>{try{gate.remove()}catch{}},800)},220);
    });
  }

  function makeLogoIntro(onDone){
    if(document.querySelector('#hs-logo-intro')){if(onDone)onDone();return;}
    const intro=document.createElement('div');
    intro.id='hs-logo-intro';
    intro.innerHTML=`<div class="hs-intro-grid"></div><div class="hs-intro-scan"></div><div class="hs-intro-impact"></div><div class="hs-intro-slash"></div><div class="hs-intro-speedflash"></div><div class="hs-intro-streaks"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="hs-intro-sparks">${Array.from({length:72},(_,i)=>`<b style="--i:${i}"></b>`).join('')}</div><div class="hs-intro-shards">${Array.from({length:24},(_,i)=>`<i style="--i:${i}"></i>`).join('')}</div><div class="hs-logo-intro-glow"></div><div class="hs-intro-pre">FROM RIDGE COUNTY</div><div class="hs-logo-intro-mark" data-text="HOLESHOT">HOLE<span>SHOT</span></div><div class="hs-logo-intro-sub">RIDE YOUR LINE.</div><div class="hs-logo-intro-line"></div><div class="hs-intro-build">BUILD 26.10 // ONLINE SESSION</div><div class="hs-logo-intro-corners"><i></i><i></i><i></i><i></i></div>`;
    document.body.appendChild(intro);

    const audio=document.createElement('audio');
    audio.id='hs-logo-sting-audio';
    audio.src=LOGO_STING_SRC;
    audio.preload='auto';
    audio.autoplay=true;
    audio.setAttribute('playsinline','');
    document.body.appendChild(audio);

    let finished=false;
    const finish=()=>{
      if(finished)return; finished=true;
      intro.classList.add('hs-logo-out');
      setTimeout(()=>{
        try{audio.pause();audio.remove()}catch{}
        try{intro.remove()}catch{}
        if(onDone)onDone();
      },1050);
    };

    requestAnimationFrame(()=>requestAnimationFrame(()=>{intro.classList.add('hs-logo-in');setTimeout(()=>intro.classList.add('hs-impact-hit'),260);setTimeout(()=>intro.classList.remove('hs-impact-hit'),1080);}));
    audio.addEventListener('ended',finish,{once:true});
    audio.addEventListener('error',()=>setTimeout(finish,900),{once:true});

    const tryPlay=async()=>{
      try{await audio.play();}
      catch(e){
        console.warn('HoleShot logo sting autoplay was blocked by the browser.',e);
        /* Keep the logo intro cinematic even when browser policy blocks sound. */
        setTimeout(finish,6900);
      }
    };
    tryPlay();
    setTimeout(finish,9000);
  }

  function makeLoading(){
    if(document.querySelector('#hs-cinematic-loading')) return;
    const el=document.createElement('div');
    el.id='hs-cinematic-loading';
    el.classList.add('hs-awaiting-start');
    el.innerHTML=`<div class="hs-load-bg"></div><div class="hs-load-scene hs-scene-1"></div><div class="hs-load-scene hs-scene-2"></div><div class="hs-load-scene hs-scene-3"></div><div class="hs-speed-lines"></div><div class="hs-vignette"></div><div class="hs-grain"></div><div class="hs-load-sweep"></div><div class="hs-load-flash"></div>
      <div class="hs-load-top"><span>HOLESHOT // RIDGE COUNTY</span><b>LIVE SESSION // BUILD 26.10</b></div>
      <div class="hs-load-chapter"><small id="hs-chapter-num">01 / 04</small><b id="hs-chapter-title">RIDGE COUNTY</b><span id="hs-chapter-copy">WHERE THE RIDE STARTS.</span></div>
      <div class="hs-load-content"><div class="hs-load-kicker">RIDE SYSTEM // INITIALIZATION</div><div class="hs-load-logo">HOLE<i>SHOT</i></div><div class="hs-load-sub" id="hs-load-sub">STREET • DIRT • WHEELIES • RIDEOUTS</div><div class="hs-load-rule"></div><div class="hs-load-caption" id="hs-load-caption">BUILDING YOUR SESSION</div></div>
      <div class="hs-load-orbit"><i></i><i></i><i></i><b>HS</b><span>RIDE<br>SYSTEM</span></div>
      <div class="hs-load-readout"><div><small>WORLD</small><b id="hs-world-state">RIDGE COUNTY</b></div><div><small>PHYSICS</small><b id="hs-physics-state">REALTIME</b></div><div><small>SESSION</small><b id="hs-session-state">STANDBY</b></div></div>
      <div class="hs-load-tease"><span id="hs-tease-label">NEXT</span><b id="hs-tease-title">MX GRAND LOOP</b><small id="hs-tease-copy">DIRT. AIR. BALANCE.</small></div>
      <div class="hs-load-bottom"><div class="hs-load-progress-wrap"><div class="hs-load-progress-head"><span id="hs-load-status">READY TO INITIALIZE</span><b id="hs-load-percent">00%</b></div><div class="hs-load-progress"><i id="hs-load-bar"></i></div><div class="hs-load-ticks"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div><button id="hs-load-game">START THE SESSION <span>↗</span></button></div><div class="hs-load-music"><span>NOW PLAYING // INTRO AUDIO</span><b id="hs-audio-state">PRESS START TO BEGIN</b></div></div>`
    document.body.appendChild(el);

    const btn=el.querySelector('#hs-load-game');
    const status=el.querySelector('#hs-load-status');
    const pct=el.querySelector('#hs-load-percent');
    const bar=el.querySelector('#hs-load-bar');
    const audioState=el.querySelector('#hs-audio-state');
    const chapterNum=el.querySelector('#hs-chapter-num');
    const chapterTitle=el.querySelector('#hs-chapter-title');
    const chapterCopy=el.querySelector('#hs-chapter-copy');
    const teaseTitle=el.querySelector('#hs-tease-title');
    const teaseCopy=el.querySelector('#hs-tease-copy');
    const loadSub=el.querySelector('#hs-load-sub');
    const loadCaption=el.querySelector('#hs-load-caption');
    const worldState=el.querySelector('#hs-world-state');
    const chapters=[
      {at:0,num:'01 / 04',title:'RIDGE COUNTY',copy:'WHERE THE RIDE STARTS.',tease:'MX GRAND LOOP',teaseCopy:'DIRT. AIR. BALANCE.',sub:'STREET • DIRT • WHEELIES • RIDEOUTS',caption:'BUILDING YOUR SESSION',world:'RIDGE COUNTY'},
      {at:25,num:'02 / 04',title:'MX GRAND LOOP',copy:'FIND THE LINE. THEN SEND IT.',tease:'RIDGE CITY',teaseCopy:'TRAFFIC. LIGHTS. CHAOS.',sub:'JUMPS • WHIPS • LANDINGS • LINES',caption:'LOADING TERRAIN + SUSPENSION',world:'MX GRAND LOOP'},
      {at:52,num:'03 / 04',title:'RIDGE CITY',copy:'THE STREET NEVER STAYS QUIET.',tease:'ENDLESS HIGHWAY',teaseCopy:'NO FINISH LINE.',sub:'STREETS • TRAFFIC • RIDEOUTS • NIGHT',caption:'SYNCING WORLD + PLAYERS',world:'RIDGE CITY'},
      {at:78,num:'04 / 04',title:'ENDLESS HIGHWAY',copy:'NO FINISH LINE.',tease:'YOUR RIDE',teaseCopy:'MAKE IT YOURS.',sub:'SPEED • DISTANCE • NIGHT RUNS',caption:'FINALIZING LIVE SESSION',world:'ENDLESS HIGHWAY'}
    ];
    let chapterIndex=-1;
    const setChapter=(n)=>{
      let idx=0; for(let i=0;i<chapters.length;i++) if(n>=chapters[i].at) idx=i;
      if(idx===chapterIndex)return; chapterIndex=idx; const c=chapters[idx];
      el.dataset.chapter=String(idx+1); el.classList.remove('hs-chapter-cut'); void el.offsetWidth; el.classList.add('hs-chapter-cut');
      if(chapterNum)chapterNum.textContent=c.num;if(chapterTitle)chapterTitle.textContent=c.title;if(chapterCopy)chapterCopy.textContent=c.copy;
      if(teaseTitle)teaseTitle.textContent=c.tease;if(teaseCopy)teaseCopy.textContent=c.teaseCopy;if(loadSub)loadSub.textContent=c.sub;if(loadCaption)loadCaption.textContent=c.caption;if(worldState)worldState.textContent=c.world;
    };
    let phase='start';

    setChapter(0);
    const beginLoading=async()=>{
      if(phase!=='start') return;
      phase='loading';
      el.classList.remove('hs-awaiting-start');
      el.classList.add('hs-loading-active');
      btn.disabled=true;
      btn.textContent='LOADING...';
      if(audioState) audioState.textContent='INTRO AUDIO // FADING IN';
      await startMusic();
      if(audioState) audioState.textContent='INTRO AUDIO // PLAYING';
      const start=performance.now();
      let p=0;
      const timer=setInterval(()=>{
        const age=performance.now()-start;
        const appReady=!!ready();
        const timeRatio=Math.min(1,age/LOAD_MS);
        const base=timeRatio*96;
        const target=(timeRatio>=1 && appReady)?100:Math.min(99,base);
        p += Math.max(.2,(target-p)*.17);
        if(target===100 && p>99.1) p=100;
        const n=Math.floor(Math.min(100,p));
        setChapter(n);
        if(bar)bar.style.width=n+'%';
        if(pct)pct.textContent=String(n).padStart(2,'0')+'%';
        if(status) status.textContent=n<26?'INITIALIZING WORLD':n<53?'LOADING BIKES & PHYSICS':n<78?'PREPARING RIDGE COUNTY':n<100?'FINALIZING SESSION':'READY TO RIDE';
        const ss=el.querySelector('#hs-session-state'); if(ss) ss.textContent=n<26?'BOOTING':n<78?'SYNCING':n<100?'VERIFYING':'READY';
        if(n>=100){
          clearInterval(timer);
          phase='ready';
          el.classList.remove('hs-loading-active');
          el.classList.add('hs-ready');
          btn.disabled=false;
          btn.innerHTML='ENTER RIDGE COUNTY <span>↗</span>';
          el.classList.add('hs-final-reveal');
          if(audioState) audioState.textContent='INTRO AUDIO // PLAYING';
        }
      },70);
    };

    const enterGame=()=>{
      if(phase!=='ready') return;
      phase='leaving';
      btn.disabled=true;
      btn.classList.add('leaving');
      if(audioState) audioState.textContent='INTRO AUDIO // FADING OUT';
      stopMusicWithFade(()=>{
        document.body.classList.add('hs-ui-unlocked');
        el.classList.add('hs-done');
        setTimeout(()=>{showSocialOnce();},700);
      });
    };

    btn.addEventListener('click',()=>{
      if(phase==='start') beginLoading();
      else if(phase==='ready') enterGame();
    });
  }

  function showSocialOnce(){
    try{if(localStorage.getItem('holeshot-tiktok-popup-seen-v1')) return}catch{}
    const pop=document.querySelector('#hs-social-popup');if(pop)setTimeout(()=>pop.classList.add('show'),250);
  }
  function closeSocial(){const pop=document.querySelector('#hs-social-popup');if(pop)pop.classList.remove('show');try{localStorage.setItem('holeshot-tiktok-popup-seen-v1','1')}catch{}}

  function decorate(){
    const menu=document.querySelector('#menu'); if(!menu || menu.dataset.hsRebuilt) return;
    menu.dataset.hsRebuilt='1';
    // Police toggle: saved locally and defaults to ON.
    window.HoleShotSettings=window.HoleShotSettings||{};
    try{window.HoleShotSettings.police=localStorage.getItem('holeshot-police')!=='off'}catch{window.HoleShotSettings.police=true}
    if(!document.getElementById('hs-settings-style')){const st=document.createElement('style');st.id='hs-settings-style';st.textContent=`#hs-settings-modal{position:fixed;inset:0;z-index:60;display:none;align-items:center;justify-content:center;background:#0009;padding:20px}#hs-settings-modal.open{display:flex}.hs-settings-card{width:min(430px,94vw);background:#14191bf7;border:1px solid #ffffff24;border-top:2px solid #d5ff65;padding:26px;box-shadow:0 20px 90px #0009}.hs-settings-card h3{font:900 italic 38px/1 'Barlow Condensed',sans-serif;margin:0 0 22px}.hs-setting-row{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:16px 0;border-top:1px solid #ffffff18}.hs-setting-row span{font-weight:700;letter-spacing:.5px}.hs-setting-row small{display:block;color:#9fa9a2;font-weight:400;margin-top:4px}.hs-toggle{width:72px;height:38px;border:1px solid #ffffff35;border-radius:20px;background:#30383a;position:relative;flex:none}.hs-toggle:after{content:'';position:absolute;width:28px;height:28px;top:4px;left:4px;border-radius:50%;background:#aeb7b1;transition:.18s}.hs-toggle.on{background:#52662f;border-color:#d5ff65}.hs-toggle.on:after{left:38px;background:#d5ff65}.hs-settings-card button.close{width:100%;margin-top:20px;padding:13px;background:#d5ff65;color:#111516;font-weight:800}`;document.head.appendChild(st)}
    if(!document.getElementById('hs-settings-modal')){const sm=document.createElement('div');sm.id='hs-settings-modal';sm.innerHTML=`<div class="hs-settings-card"><h3>SETTINGS</h3><div class="hs-setting-row"><span>POLICE<small>Enable police patrols and chases.</small></span><button class="hs-toggle" id="hs-police-toggle" aria-label="Toggle police"></button></div><button class="close" id="hs-settings-close">DONE</button></div>`;document.body.appendChild(sm);const tog=sm.querySelector('#hs-police-toggle');const sync=()=>{const on=window.HoleShotSettings.police!==false;tog.classList.toggle('on',on);tog.setAttribute('aria-pressed',String(on))};tog.addEventListener('click',()=>{window.HoleShotSettings.police=!window.HoleShotSettings.police;try{localStorage.setItem('holeshot-police',window.HoleShotSettings.police?'on':'off')}catch{}sync()});sm.querySelector('#hs-settings-close').addEventListener('click',()=>sm.classList.remove('open'));sm.addEventListener('click',e=>{if(e.target===sm)sm.classList.remove('open')});sync()}

    const eye=menu.querySelector('.eyebrow');if(eye)eye.textContent='HOLESHOT // RIDGE COUNTY';
    const h1=menu.querySelector('h1');if(h1)h1.innerHTML='HOLE<br><em>SHOT</em>';
    const intro=menu.querySelector('.intro');if(intro)intro.textContent='CHOOSE YOUR SESSION // RIDGE COUNTY IS YOURS';
    const play=menu.querySelector('#play');if(play)play.innerHTML='ENTER THE RIDE <span>↗</span>';
    const garage=menu.querySelector('#garage-button');if(garage){const span=garage.querySelector('span');garage.childNodes[0].textContent='CUSTOMIZE BIKE ';if(span)span.textContent='GARAGE ↗'}
    const builder=menu.querySelector('#builder-button');if(builder)builder.textContent='BUILD A TRACK ↗';
    // SERVERS is part of the rebuilt main menu itself so it cannot disappear due to script timing.
    if(!menu.querySelector('#hs-menu-servers')){
      const servers=document.createElement('button');
      servers.id='hs-menu-servers';
      servers.className='hs-menu-servers-native';
      servers.innerHTML='SERVERS <span>GLOBAL ↗</span>';
      servers.addEventListener('click',()=>{
        if(typeof window.openHoleShotServers==='function') window.openHoleShotServers();
        else setTimeout(()=>typeof window.openHoleShotServers==='function'&&window.openHoleShotServers(),250);
      });
      const links=menu.querySelector('.menu-links');
      if(links) links.appendChild(servers);
      else if(builder) builder.insertAdjacentElement('afterend',servers);
      else (menu.querySelector('.panel')||menu).appendChild(servers);
    }
    if(!menu.querySelector('#hs-menu-settings')){const settings=document.createElement('button');settings.id='hs-menu-settings';settings.className='hs-menu-settings';settings.textContent='SETTINGS';settings.addEventListener('click',()=>{const sm=document.getElementById('hs-settings-modal');if(sm){sm.classList.add('open');const tog=sm.querySelector('#hs-police-toggle');const on=window.HoleShotSettings.police!==false;tog.classList.toggle('on',on);tog.setAttribute('aria-pressed',String(on))}});const links=menu.querySelector('.menu-links');if(links)links.appendChild(settings);else (menu.querySelector('.panel')||menu).appendChild(settings)}
    const deco=document.createElement('div');deco.className='hs-menu-deco';deco.innerHTML='<div class="num">HOLESHOT // RIDGE COUNTY</div><strong>RIDE YOUR LINE.</strong><span>STREET • DIRT • RIDEOUTS • STUNTS</span>';document.body.appendChild(deco);

    const popup=document.createElement('div');popup.id='hs-social-popup';popup.innerHTML=`<div class="hs-social-card"><div class="tag">HOLESHOT COMMUNITY</div><h3>FOLLOW THE BUILD.</h3><p>Follow the official HoleShot TikTok account for game updates, new bikes, development clips, and upcoming features.</p><div class="hs-social-actions"><a href="${TIKTOK}" target="_blank" rel="noopener">FOLLOW @HOLESHOT.IO ↗</a><button id="hs-social-later">MAYBE LATER</button></div></div>`;document.body.appendChild(popup);
    popup.querySelector('#hs-social-later').addEventListener('click',closeSocial);popup.addEventListener('click',e=>{if(e.target===popup)closeSocial()});popup.querySelector('a').addEventListener('click',()=>setTimeout(closeSocial,150));
    observeMenu(menu);
  }
  function observeMenu(menu){
    const sync=()=>{const visible=!menu.classList.contains('hidden') && getComputedStyle(menu).display!=='none';document.body.classList.toggle('hs-front-menu',visible);const d=document.querySelector('.hs-menu-deco');if(d)d.style.display=visible?'':'none'};
    new MutationObserver(sync).observe(menu,{attributes:true,attributeFilter:['class','style']}); sync();
  }

  function boot(){
    makePowerGate(()=>makeLogoIntro(()=>makeLoading()));
    const poll=setInterval(()=>{if(ready()){clearInterval(poll);decorate()}},50);
    setTimeout(()=>clearInterval(poll),30000);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();

})();
