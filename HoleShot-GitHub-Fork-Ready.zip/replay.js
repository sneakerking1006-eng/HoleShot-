(()=>{
  const $=s=>document.querySelector(s);
  function boot(){
    const api=window.__HOLESHOT_3D_REPLAY_INTERNALS__;
    if(!api?.bike||!api?.camera){setTimeout(boot,250);return}
    if(window.__HOLESHOT_3D_REPLAY_READY__)return;
    window.__HOLESHOT_3D_REPLAY_READY__=true;

    const style=document.createElement('style');
    style.textContent=`
      #crash-replay-btn{position:fixed;z-index:90;left:50%;bottom:90px;transform:translateX(-50%);padding:14px 22px;background:#11191ce8;border:1px solid #d5ff65;color:#d5ff65;border-radius:8px;font:800 14px Barlow,Arial,sans-serif;letter-spacing:1.2px;display:none;box-shadow:0 8px 28px #0009}
      #crash-replay-btn.show{display:block}
      #replay3d{position:fixed;z-index:88;inset:0;display:none;pointer-events:none}
      #replay3d.open{display:block}
      #replay3d-look{position:absolute;inset:0;pointer-events:auto;cursor:grab;touch-action:none}
      #replay3d-look.drag{cursor:grabbing}
      #replay3d-top{position:absolute;z-index:2;top:18px;left:50%;transform:translateX(-50%);padding:9px 14px;background:#101719d9;border:1px solid #ffffff30;border-radius:7px;color:#fff;font:800 14px Barlow,Arial,sans-serif;letter-spacing:1.5px;pointer-events:none}
      #replay3d-bar{position:absolute;z-index:3;bottom:24px;left:50%;transform:translateX(-50%);display:flex;gap:7px;flex-wrap:wrap;justify-content:center;pointer-events:auto;background:#101719d9;border:1px solid #ffffff2b;border-radius:9px;padding:8px}
      #replay3d-bar button{padding:11px 14px;border:1px solid #ffffff45;background:#172126;color:#f4f7f1;font:800 13px Barlow,Arial,sans-serif;border-radius:6px;min-width:54px}
      #replay3d-bar button.active{color:#101516;background:#d5ff65;border-color:#d5ff65}
      #replay3d-hint{position:absolute;z-index:2;top:58px;left:50%;transform:translateX(-50%);padding:6px 10px;background:#101719b8;color:#e8eee2;border-radius:5px;font:600 12px Barlow,Arial,sans-serif;pointer-events:none;white-space:nowrap}
      body.replay3d-active #hud,body.replay3d-active header,body.replay3d-active #photo-open,body.replay3d-active #personal-bests,body.replay3d-active #run-feedback,body.replay3d-active #debug,body.replay3d-active #toast,body.replay3d-active #race-again,body.replay3d-active #walk-toggle,body.replay3d-active #wheelie-tricks{display:none!important}
    `;
    document.head.appendChild(style);

    const btn=document.createElement('button');btn.id='crash-replay-btn';btn.textContent='↻ REPLAY CRASH';document.body.appendChild(btn);
    const ui=document.createElement('div');ui.id='replay3d';ui.innerHTML=`<div id="replay3d-look"></div><div id="replay3d-top">3D CRASH REPLAY</div><div id="replay3d-hint">Drag to orbit · Scroll/pinch to zoom</div><div id="replay3d-bar"><button data-speed="1" class="active">1×</button><button data-speed="0.5">0.5×</button><button data-speed="0.25">0.25×</button><button id="replay-pause">PAUSE</button><button id="replay-again">↻ AGAIN</button><button id="replay-close">CLOSE</button></div>`;document.body.appendChild(ui);
    const look=$('#replay3d-look'), cam=api.camera;

    let riderNodes=[];
    function refreshRiderNodes(){
      riderNodes=[];
      const r=window.__HOLESHOT_3D_REPLAY_INTERNALS__?.rider;
      if(r&&r.traverse)r.traverse(o=>riderNodes.push(o));
    }
    refreshRiderNodes();

    const ring=[]; const maxMs=11000; let lastCapture=0, wasCrashed=false, crashAt=0, pending=false, clip=[];
    function snap(now){
      const a=window.__HOLESHOT_3D_REPLAY_INTERNALS__; if(!a?.bike)return;
      if(!riderNodes.length&&a.rider)refreshRiderNodes();
      const b=a.bike;
      const frame={t:now,bp:[b.position.x,b.position.y,b.position.z],bq:[b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w],bs:[b.scale.x,b.scale.y,b.scale.z],r:[]};
      for(const o of riderNodes)frame.r.push([o.position.x,o.position.y,o.position.z,o.quaternion.x,o.quaternion.y,o.quaternion.z,o.quaternion.w,o.scale.x,o.scale.y,o.scale.z]);
      ring.push(frame); while(ring.length&&ring[0].t<now-maxMs)ring.shift();
    }
    function captureLoop(now){
      if(!active&&now-lastCapture>=33){lastCapture=now;snap(now)}
      const st=window.__HOLESHOT_STATE__, crashed=!!(st&&st.crashed>0);
      if(crashed&&!wasCrashed){crashAt=now;pending=true;btn.classList.remove('show');setTimeout(prepare,3000)}
      wasCrashed=crashed; requestAnimationFrame(captureLoop);
    }
    requestAnimationFrame(captureLoop);
    function prepare(){
      if(!pending)return; const from=crashAt-5000,to=crashAt+2800; clip=ring.filter(f=>f.t>=from&&f.t<=to); pending=false;if(clip.length>15){btn.classList.add('show');clearTimeout(btn._hsHideTimer);btn._hsHideTimer=setTimeout(()=>btn.classList.remove('show'),5000)}
    }

    let active=false,playing=true,speed=1,playT=0,lastNow=0,index=0;
    let yaw=0,pitch=.24,radius=5.5,camSaved=null,drag=false,lx=0,ly=0,pinchDist=0;
    function setupCamera(){
      const f=clip[Math.min(index,clip.length-1)]; if(!f)return;
      const tx=f.bp[0],ty=f.bp[1]+.65,tz=f.bp[2];
      const dx=cam.position.x-tx,dz=cam.position.z-tz,dy=cam.position.y-ty;
      radius=Math.max(2.2,Math.min(11,Math.hypot(dx,dy,dz)||5.5)); yaw=Math.atan2(dx,dz); pitch=Math.asin(Math.max(-.85,Math.min(.85,dy/radius)));
    }
    function applyFrame(f,dt){
      const a=window.__HOLESHOT_3D_REPLAY_INTERNALS__; if(!a?.bike||!f)return;
      const b=a.bike;b.position.set(...f.bp);b.quaternion.set(...f.bq);b.scale.set(...f.bs);b.updateMatrixWorld(true);
      if(a.rider&&riderNodes.length===f.r.length){for(let i=0;i<riderNodes.length;i++){const o=riderNodes[i],v=f.r[i];o.position.set(v[0],v[1],v[2]);o.quaternion.set(v[3],v[4],v[5],v[6]);o.scale.set(v[7],v[8],v[9])}a.rider.updateMatrixWorld(true)}
      const target={x:f.bp[0],y:f.bp[1]+.62,z:f.bp[2]};
      const cp=Math.cos(pitch); cam.position.set(target.x+Math.sin(yaw)*cp*radius,target.y+Math.sin(pitch)*radius,target.z+Math.cos(yaw)*cp*radius);cam.lookAt(target.x,target.y,target.z);cam.updateProjectionMatrix();
      // Re-fire metal contact sparks during the 3D replay from actual bike contact points.
      const local=[[-.46,.53,.34],[.46,.53,.34],[-.2,-.28,-.18],[.2,-.28,-.18],[0,-.42,.56],[0,-.42,-.56],[-.15,-.3,-.22],[.15,-.3,-.22],[-.13,-.28,-.48],[.13,-.28,-.48]];
      if(a.contactFx&&a.ground){
        const V=b.position.constructor;
        const prev=clip[Math.max(0,index-1)], movement=prev?Math.hypot(f.bp[0]-prev.bp[0],f.bp[1]-prev.bp[1],f.bp[2]-prev.bp[2])*30:0;
        for(let i=0;i<Math.min(local.length,a.contactFx.length);i++){
          const v=new V(local[i][0],local[i][1],local[i][2]);b.localToWorld(v);const gy=a.ground(v.x,v.z),touch=v.y<=gy+.1;if(touch)v.y=gy+.025;a.contactFx[i].update(v,touch,Math.max(4,movement),yaw,Math.max(.001,dt||.016));
        }
      }
    }
    window.__HOLESHOT_3D_REPLAY_APPLY__=(dt)=>{
      if(!active||!clip.length)return;
      const now=performance.now(); if(!lastNow)lastNow=now;
      if(playing)playT+=(now-lastNow)*speed;lastNow=now;
      const start=clip[0].t,target=start+playT;
      while(index<clip.length-1&&clip[index+1].t<=target)index++;
      if(index>=clip.length-1){index=clip.length-1;playing=false;$('#replay-pause').textContent='PLAY'}
      applyFrame(clip[index],dt);
    };

    function openReplay(){if(!clip.length)return;active=true;playing=true;speed=1;playT=0;index=0;lastNow=performance.now();camSaved={p:cam.position.clone(),q:cam.quaternion.clone(),fov:cam.fov};setupCamera();ui.classList.add('open');document.body.classList.add('replay3d-active');btn.classList.remove('show');setSpeed(1)}
    function closeReplay(){active=false;playing=false;ui.classList.remove('open');document.body.classList.remove('replay3d-active');btn.classList.add('show');if(camSaved){cam.position.copy(camSaved.p);cam.quaternion.copy(camSaved.q);cam.fov=camSaved.fov;cam.updateProjectionMatrix()}lastNow=0}
    function restart(){playT=0;index=0;playing=true;lastNow=performance.now();$('#replay-pause').textContent='PAUSE'}
    function setSpeed(v){speed=v;ui.querySelectorAll('[data-speed]').forEach(b=>b.classList.toggle('active',Number(b.dataset.speed)===v))}
    btn.onclick=openReplay;$('#replay-close').onclick=closeReplay;$('#replay-again').onclick=restart;$('#replay-pause').onclick=()=>{playing=!playing;lastNow=performance.now();$('#replay-pause').textContent=playing?'PAUSE':'PLAY'};
    ui.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>setSpeed(Number(b.dataset.speed)));

    look.addEventListener('pointerdown',e=>{drag=true;lx=e.clientX;ly=e.clientY;look.classList.add('drag');look.setPointerCapture?.(e.pointerId)});
    look.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;yaw-=dx*.006;pitch=Math.max(-1.05,Math.min(1.05,pitch+dy*.005))});
    const end=()=>{drag=false;look.classList.remove('drag')};look.addEventListener('pointerup',end);look.addEventListener('pointercancel',end);
    look.addEventListener('wheel',e=>{e.preventDefault();radius=Math.max(1.6,Math.min(14,radius*(1+Math.sign(e.deltaY)*.09)))},{passive:false});
    look.addEventListener('touchstart',e=>{if(e.touches.length===2)pinchDist=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY)},{passive:false});
    look.addEventListener('touchmove',e=>{if(e.touches.length===2){e.preventDefault();const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(pinchDist){radius=Math.max(1.6,Math.min(14,radius*pinchDist/d))}pinchDist=d}},{passive:false});
  }
  boot();
})();
