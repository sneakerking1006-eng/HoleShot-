(()=>{
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;
  function boot(){
    const api=window.__HOLESHOT_3D_REPLAY_INTERNALS__;
    if(!api?.bike||!api?.state){setTimeout(boot,250);return}
    if(window.__HOLESHOT_DAMAGE_READY__)return;
    window.__HOLESHOT_DAMAGE_READY__=true;

    const style=document.createElement('style');
    style.textContent=`
      #damage-hud{position:fixed;z-index:18;right:22px;top:206px;min-width:178px;padding:10px 12px;background:#11191ce8;border:1px solid #ffffff30;border-radius:7px;color:#fff;font:800 12px Barlow,Arial,sans-serif;letter-spacing:.8px;display:none;pointer-events:none}
      #damage-hud.show{display:block}#damage-hud strong{display:block;color:#ffb05a;font-size:13px;margin-bottom:5px}#damage-bar{height:5px;background:#ffffff22;margin-top:7px;overflow:hidden}#damage-bar i{display:block;height:100%;width:0;background:#ff884a}
      #repair-bike-btn{position:fixed;z-index:19;right:22px;top:286px;padding:10px 13px;background:#151d20e8;border:1px solid #ffb05a;color:#ffb05a;border-radius:7px;font:800 12px Barlow,Arial,sans-serif;letter-spacing:.8px;display:none}
      #repair-bike-btn.show{display:block}body.photo-active #damage-hud,body.photo-active #repair-bike-btn,body.replay3d-active #damage-hud,body.replay3d-active #repair-bike-btn{display:none!important}
      @media(max-width:700px){#damage-hud{right:12px;top:126px;min-width:145px;font-size:10px}#repair-bike-btn{right:12px;top:198px;font-size:10px;padding:8px 10px}}
    `;
    document.head.appendChild(style);
    const hud=document.createElement('div');hud.id='damage-hud';hud.innerHTML='<strong>BIKE DAMAGE</strong><span id="damage-text">0%</span><div id="damage-bar"><i></i></div>';document.body.appendChild(hud);
    const repair=document.createElement('button');repair.id='repair-bike-btn';repair.textContent='REPAIR BIKE';document.body.appendChild(repair);

    const original=new Map();
    const damagedNodes=[];
    const wheelNodes=[];
    const paintNodes=[];
    const originalMats=new Map();
    function activeVisible(o){
      let n=o;while(n){if(n.visible===false)return false;n=n.parent}return true;
    }
    function remember(o){
      if(!original.has(o))original.set(o,{p:o.position.clone(),q:o.quaternion.clone(),s:o.scale.clone(),rx:o.rotation?.x||0,ry:o.rotation?.y||0,rz:o.rotation?.z||0});
    }
    function rememberMaterial(o){
      if(!o?.material||originalMats.has(o))return;
      const mats=Array.isArray(o.material)?o.material:[o.material];
      originalMats.set(o,mats.map(m=>({
        mat:m,
        color:m?.color?.clone?.()||null,
        roughness:typeof m?.roughness==='number'?m.roughness:null,
        metalness:typeof m?.metalness==='number'?m.metalness:null,
        emissive:m?.emissive?.clone?.()||null,
        emissiveIntensity:typeof m?.emissiveIntensity==='number'?m.emissiveIntensity:null
      })));
    }
    function restorePaint(){
      for(const [o,arr] of originalMats){
        if(!o)continue;
        for(const rec of arr){
          const m=rec.mat;if(!m)continue;
          if(rec.color&&m.color?.copy)m.color.copy(rec.color);
          if(rec.roughness!==null)m.roughness=rec.roughness;
          if(rec.metalness!==null)m.metalness=rec.metalness;
          if(rec.emissive&&m.emissive?.copy)m.emissive.copy(rec.emissive);
          if(rec.emissiveIntensity!==null)m.emissiveIntensity=rec.emissiveIntensity;
          m.needsUpdate=true;
        }
      }
    }
    function scan(){
      damagedNodes.length=0;wheelNodes.length=0;paintNodes.length=0;
      api.bike.traverse?.(o=>{
        if(o===api.bike||!activeVisible(o))return;
        const part=(o.userData?.customPart||'').toLowerCase();
        const name=(o.name||'').toLowerCase();
        const gt=(o.geometry?.type||'').toLowerCase();
        const wheelish=/wheel|rim|tire|tyre/.test(name)||gt.includes('torus');
        if(o.material){rememberMaterial(o);if(part==='frame'||part==='fork'||/frame|fork/.test(name))paintNodes.push(o)}
        if(wheelish){remember(o);wheelNodes.push(o)}
        if(part==='frame'||part==='fork'||part==='seat'||/handle|bar|guard|fender|swing|peg|lever|axle|brace/.test(name)){
          remember(o);damagedNodes.push({o,part:part||name});
        }
      });
    }
    scan();

    let damage=0,wasCrashed=false,lastReset=api.state.resetCount||0;
    let base={handling:api.state.handlingTune||1,brake:api.state.brakeTune||1,spring:api.state.springTune||1,power:api.state.powerTune||1};
    let crashSeed=1;
    const rand=(k)=>{const x=Math.sin((crashSeed+k)*12.9898)*43758.5453;return x-Math.floor(x)};

    function restoreVisual(){
      restorePaint();
      for(const [o,v] of original){
        if(!o?.position)continue;
        o.position.copy(v.p);o.quaternion.copy(v.q);o.scale.copy(v.s);
      }
    }
    function applyVisual(){
      restoreVisual();
      if(damage<=.01)return;
      const mild=clamp(damage/.45,0,1), severe=clamp((damage-.38)/.62,0,1);
      let i=0;
      for(const {o,part} of damagedNodes){
        const v=original.get(o);if(!v)continue;
        const side=rand(i*3+1)>.5?1:-1;
        if(part.includes('fork')){
          o.rotation.z += side*lerp(.015,.13,severe)*mild;
          o.rotation.x += (rand(i+4)-.5)*.045*damage;
          o.position.x += side*.018*severe;
        }else if(part.includes('frame')){
          o.rotation.z += side*(.008+.055*severe)*(rand(i+7)*.7+.3);
          o.rotation.x += (rand(i+9)-.5)*.05*severe;
          o.scale.y *= 1-.035*severe;
        }else if(part.includes('seat')){
          o.rotation.z += side*.08*severe;
          o.rotation.x += -.08*severe;
          o.position.y -= .035*severe;
        }else{
          o.rotation.z += side*.1*severe;
          o.position.x += side*.025*severe;
        }
        i++;
      }
      i=0;
      for(const o of wheelNodes){
        if(!activeVisible(o)){i++;continue}
        const side=i%2?1:-1;
        o.rotation.z += side*.075*severe;
        o.scale.y *= 1-.06*severe;
        o.scale.x *= 1+.025*severe;
        i++;
      }
      applyPaintDamage();
    }
    function applyPaintDamage(){
      if(damage<=.28)return;
      const light=clamp((damage-.28)/.30,0,1);
      const medium=clamp((damage-.48)/.30,0,1);
      const severe=clamp((damage-.72)/.28,0,1);
      let idx=0;
      for(const o of paintNodes){
        if(!activeVisible(o)){idx++;continue}
        const arr=originalMats.get(o);if(!arr){idx++;continue}
        // More parts get visibly scuffed as damage rises. This makes the wear spread
        // instead of tinting the entire bike at the first small crash.
        const exposure=rand(idx*11+31);
        const threshold=.97-light*.12-medium*.26-severe*.42;
        if(exposure<threshold){idx++;continue}
        const local=clamp((light*.10+medium*.28+severe*.62)*(0.55+rand(idx*7+4)*.45),0,.78);
        for(const rec of arr){
          const m=rec.mat;if(!m)continue;
          if(rec.color&&m.color){
            // Blend toward scraped metal / abraded plastic gray. Severe damage can
            // almost strip the original color from the most exposed pieces.
            const base=rec.color;
            const gray=(base.r+base.g+base.b)/3;
            const targetR=.34+gray*.18,targetG=.35+gray*.16,targetB=.36+gray*.14;
            m.color.setRGB(
              lerp(base.r,targetR,local),
              lerp(base.g,targetG,local),
              lerp(base.b,targetB,local)
            );
          }
          if(rec.roughness!==null)m.roughness=clamp(lerp(rec.roughness,.96,local*.9),0,1);
          if(rec.metalness!==null)m.metalness=clamp(lerp(rec.metalness,.08,local*.55),0,1);
          if(m.emissive&&rec.emissive)m.emissive.copy(rec.emissive).multiplyScalar(1-local*.75);
          if(rec.emissiveIntensity!==null)m.emissiveIntensity=rec.emissiveIntensity*(1-local*.7);
          m.needsUpdate=true;
        }
        idx++;
      }
    }
    function applyPhysics(){
      const s=clamp((damage-.18)/.82,0,1);
      api.state.handlingTune=base.handling*(1-.38*s);
      api.state.brakeTune=base.brake*(1-.22*s);
      api.state.springTune=base.spring*(1-.3*s);
      api.state.powerTune=base.power*(1-.1*s);
    }
    function ui(){
      if(damage>.08){hud.classList.add('show');repair.classList.add('show')}else{hud.classList.remove('show');repair.classList.remove('show')}
      const pct=Math.round(damage*100);const label=damage>.78?'SEVERE · '+pct+'%':damage>.5?'HEAVY · '+pct+'%':damage>.23?'MODERATE · '+pct+'%':pct+'%';
      const t=document.getElementById('damage-text');const b=document.querySelector('#damage-bar i');if(t)t.textContent=label;if(b)b.style.width=pct+'%';
    }
    function doRepair(){
      damage=0;restoreVisual();
      api.state.handlingTune=base.handling;api.state.brakeTune=base.brake;api.state.springTune=base.spring;api.state.powerTune=base.power;
      ui();scan();
    }
    repair.onclick=doRepair;

    function impactDamage(st){
      const mph=Math.abs(st?.mph||0),vy=Math.abs(st?.verticalSpeed||0);
      const rot=st?.rotation||{};const tilt=(Math.abs(rot.roll||0)+Math.abs(rot.pitch||0))*180/Math.PI;
      const reason=st?.crashReason||'';
      let score=mph*.0065+vy*.032+tilt*.00115;
      if(reason==='loop')score+=.10;
      if(mph>42)score+=.055;if(vy>12)score+=.07;
      // Ignore small tip-overs and low-energy crashes.
      if(score<.14)return 0;
      return clamp((score-.10)*.9,0,.72);
    }
    function onCrash(st){
      crashSeed=(Date.now()%100000)+Math.round((st?.mph||0)*13);
      const add=impactDamage(st);
      // Hard crashes accumulate quickly; a single huge impact can nearly total the bike.
      damage=clamp(damage+add*(1-damage*.45),0,1);
      scan();applyVisual();applyPhysics();ui();
      try{
        const toast=document.getElementById('toast');
        if(toast&&damage>.45){toast.textContent=damage>.78?'SEVERE BIKE DAMAGE':'HEAVY BIKE DAMAGE';toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),1800)}
      }catch{}
    }

    function animate(){
      const st=window.__HOLESHOT_STATE__;
      if(!st){requestAnimationFrame(animate);return}
      const crashed=!!(st.crashed>0);
      if(crashed&&!wasCrashed)onCrash(st);
      wasCrashed=crashed;
      const rc=api.state.resetCount||0;
      // Crash recovery/respawn may change resetCount. Do NOT auto-repair here;
      // damage persists until the player deliberately presses REPAIR BIKE.
      if(rc!==lastReset){lastReset=rc}
      if(damage<=.01&&!crashed){base={handling:api.state.handlingTune||1,brake:api.state.brakeTune||1,spring:api.state.springTune||1,power:api.state.powerTune||1}}
      // Visual damage is intentionally static. Bent/crooked parts stay displaced
      // until repaired; no per-frame shaking or wobble is added.
      requestAnimationFrame(animate);
    }
    requestAnimationFrame(animate);
    window.__HOLESHOT_DAMAGE__={repair:doRepair,get level(){return damage}};
  }
  boot();
})();
