(()=>{
  // Simple HoleShot cash economy. Houses and gas/charging stations removed.
  const K='hs-economy-v1';
  const load=()=>{try{const old=JSON.parse(localStorage.getItem(K)||'null')||{};return{...old,balance:Number.isFinite(old.balance)?old.balance:2500}}catch{return{balance:2500}}};
  let data=load();
  const save=()=>{try{localStorage.setItem(K,JSON.stringify(data))}catch{}};
  let money,last=performance.now(),wheelieRun=0;
  const fmt=n=>'$'+Math.floor(n).toLocaleString();
  function updateHUD(){if(money)money.textContent=fmt(data.balance)}
  window.HoleShotEconomy={get balance(){return data.balance},set balance(v){data.balance=Math.max(0,Number(v)||0);save();updateHUD()},data,add(n){data.balance+=Number(n)||0;save();updateHUD()}};
  function build(){
    if(!document.querySelector('#hs-money')){money=document.createElement('div');money.id='hs-money';document.body.appendChild(money);updateHUD()}
    document.querySelector('#hs-battery')?.remove();
    document.querySelector('#hs-station-prompt')?.remove();
    document.querySelector('#hs-property-button')?.remove();
    document.querySelectorAll('.hs-econ-overlay').forEach(x=>x.remove());
  }
  function tick(now){
    build();
    const st=window.__HOLESHOT_STATE__,dt=Math.min(.1,(now-last)/1000);last=now;
    if(st){
      const wheeling=st.wheelie>14&&st.speed>2&&st.crashed<=0;
      if(wheeling){const rate=1.8+Math.min(5,(st.wheelie-14)*.08)+Math.min(4,Math.abs(st.mph||0)*.05);const earn=rate*dt;wheelieRun+=earn;data.balance+=earn}
      else if(wheelieRun>0){data.balance+=Math.min(125,wheelieRun*.15);wheelieRun=0;save()}
      if(Math.random()<.02)save();updateHUD();
    }
    requestAnimationFrame(tick)
  }
  new MutationObserver(build).observe(document.documentElement,{subtree:true,childList:true});
  requestAnimationFrame(tick);
})();
