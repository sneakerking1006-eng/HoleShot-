(()=>{
  if(window.__hsConversionModeInit)return;
  window.__hsConversionModeInit=true;
  const saved=localStorage.getItem('holeshot-conversion-pedal-mode');
  window.HoleShotConversionPedalMode=saved!=='off';
  const btn=document.createElement('button');
  btn.id='conversion-mode-toggle';
  btn.type='button';
  const render=()=>{btn.innerHTML=`RIDE MODE <strong>${window.HoleShotConversionPedalMode?'PEDAL':'NO PEDAL'}</strong>`};
  render();
  btn.addEventListener('click',()=>{
    window.HoleShotConversionPedalMode=!window.HoleShotConversionPedalMode;
    localStorage.setItem('holeshot-conversion-pedal-mode',window.HoleShotConversionPedalMode?'on':'off');
    render();
  });
  document.body.appendChild(btn);
  const tick=()=>{
    const st=window.__HOLESHOT_STATE__;
    document.body.classList.toggle('hs-conversion-bike',!!st&&st.bike==='64V CONVERSION E-BIKE');
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
})();
