(()=>{
  const sync=()=>{
    const vv=window.visualViewport;
    const w=Math.round(vv?.width||window.innerWidth||0);
    const h=Math.round(vv?.height||window.innerHeight||0);
    document.documentElement.style.setProperty('--hs-vvh',h+'px');
    document.documentElement.style.setProperty('--hs-vvw',w+'px');
    document.body?.classList.toggle('hs-mobile-tight',w<=600&&h<=720);
  };
  sync();
  addEventListener('resize',sync,{passive:true});
  window.visualViewport?.addEventListener('resize',sync,{passive:true});
  window.visualViewport?.addEventListener('scroll',sync,{passive:true});
})();
