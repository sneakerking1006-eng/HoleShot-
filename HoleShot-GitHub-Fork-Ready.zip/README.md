# HoleShot 🏍️⚡

HoleShot is a browser-based e-bike wheelie / rideout game.

## Fork it

1. Open the GitHub repository.
2. Click **Fork**.
3. Open your fork and clone/download it.
4. Serve the project as a static website.

Because this version is already a browser-ready build, you do **not** need a build step.

### Run locally

With Python:

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

Or with Node:

```bash
npx serve .
```

## Deploy to Netlify

This repo is configured as a static site. On Netlify, use:

- **Build command:** leave empty
- **Publish directory:** `.`

You can also drag the project folder into Netlify Drop.

## Project layout

- `index.html` — game entry page
- `assets/` — bundled game JavaScript/CSS
- `models/` — 3D assets
- `*.js` / `*.css` — game systems and UI modules
- `netlify.toml` — Netlify configuration

## Multiplayer note

The current build uses Supabase for online multiplayer/presence. Forks currently point at the same configured Supabase backend. If you publish your own public fork, set up your own Supabase project and update the client configuration before using it as a separate production game.

Never put a Supabase `service_role` key or any other private server secret in this browser project.

## License

No license is granted by this repository unless the owner adds one. Forking on GitHub does not automatically grant permission to redistribute or commercially use the game.
