# Security

Do not commit passwords, private API keys, Supabase service-role keys, tokens, or other secrets.

The browser client may contain public/publishable configuration. That configuration must still be protected by proper server-side authorization and database row-level security.
