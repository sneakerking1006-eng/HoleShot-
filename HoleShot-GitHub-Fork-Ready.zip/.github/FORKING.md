# Making your own HoleShot fork

GitHub's **Fork** button creates your own copy of this repository.

After forking:

```bash
git clone YOUR_FORK_URL
cd HoleShot
```

Then serve the folder as a static site.

If you want your fork to have independent multiplayer, replace the Supabase project configuration in `multiplayer.js` and the bundled client configuration with your own project and secure database/RLS policies.
